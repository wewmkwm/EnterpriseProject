<?php
include("connection.php");

// Fetch appointments from the database
$query = "SELECT * FROM appointments ORDER BY appointment_date DESC, time DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Appointments</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .filter-btn-group {
            display: flex;
            justify-content: center;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-between mb-3">
            <div class="col-md-6">
                <a href="index.php" class="btn btn-primary">Back</a>
            </div>
            <div class="col-md-6 text-right">
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-secondary filter-btn" data-filter="upcoming">Upcoming</button>
                    <button type="button" class="btn btn-outline-secondary filter-btn" data-filter="past">Past</button>
                    <button type="button" class="btn btn-outline-secondary filter-btn" data-filter="all">All</button>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h2>Appointments List</h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered text-center">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>View Products</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                                    <tr>
                                        <td><?php echo $row['appointment_date']; ?></td>
                                        <td><?php echo $row['time']; ?></td>
                                        <td>
                                            <a href="appointment_details.php?appointment_id=<?php echo $row['appointment_id']; ?>" class="btn btn-info">View Details</a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Filter buttons functionality
            const filterBtns = document.querySelectorAll('.filter-btn');
            filterBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const filterType = this.getAttribute('data-filter');
                    const rows = document.querySelectorAll('tbody tr');

                    rows.forEach(row => {
                        const dateCell = row.querySelector('td:first-child');
                        const appointmentDate = new Date(dateCell.textContent);
                        const today = new Date();

                        if (filterType === 'upcoming' && appointmentDate >= today) {
                            row.style.display = 'table-row';
                        } else if (filterType === 'past' && appointmentDate < today) {
                            row.style.display = 'table-row';
                        } else if (filterType === 'all') {
                            row.style.display = 'table-row';
                        } else {
                            row.style.display = 'none';
                        }
                    });
                });
            });
        });
    </script>
</body>

</html>
