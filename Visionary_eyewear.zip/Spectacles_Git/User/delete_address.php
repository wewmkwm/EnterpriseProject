<?php
include("connection.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address_id = intval($_POST['address_id']);

    // Prepare the SQL query to delete the address
    $sql = "DELETE FROM address WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $address_id);

    if ($stmt->execute()) {
        // Redirect to the address selection page after deletion
        header("Location: address.php");
        exit();
    } else {
        echo "Error deleting address: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
} else {
    // Redirect to the address selection page if the request method is not POST
    header("Location: address.php");
    exit();
}
?>
 