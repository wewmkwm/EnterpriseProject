<?php
include("connection.php");

if (isset($_GET['appointment_id'])) {
    $appointment_id = $_GET['appointment_id'];

    // Query to fetch appointment details
    $queryAppointment = "SELECT * FROM appointments WHERE appointment_id = ?";
    $stmt = mysqli_prepare($conn, $queryAppointment);
    mysqli_stmt_bind_param($stmt, "i", $appointment_id);
    mysqli_stmt_execute($stmt);
    $resultAppointment = mysqli_stmt_get_result($stmt);
    $appointment = mysqli_fetch_assoc($resultAppointment);

    if ($appointment) {
        // Query to fetch appointment products and associated models
        $queryProducts = "SELECT ap.*, m.name AS model_name FROM appointment_products ap
                          INNER JOIN models m ON ap.frame_id = m.id
                          WHERE ap.appointment_id = ?";
        $stmt = mysqli_prepare($conn, $queryProducts);
        mysqli_stmt_bind_param($stmt, "i", $appointment_id);
        mysqli_stmt_execute($stmt);
        $resultProducts = mysqli_stmt_get_result($stmt);
        $products = mysqli_fetch_all($resultProducts, MYSQLI_ASSOC);
    } else {
        echo "Appointment not found.";
        exit;
    }
} else {
    echo "Invalid appointment ID.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Details</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h2>Appointment Details</h2>
                    </div>
                    <div class="card-body">
                        <p><strong>Date:</strong> <?php echo $appointment['appointment_date']; ?></p>
                        <p><strong>Time:</strong> <?php echo $appointment['time']; ?></p>

                        <h3>Appointment Products</h3>
                        <ul>
                            <?php foreach ($products as $product) : ?>
                                <li><?php echo $product['model_name']; ?> - Quantity: <?php echo $product['frame_quantity']; ?></li>
                            <?php endforeach; ?>
                        </ul>

                        <a href="view_appointments.php" class="btn btn-primary">Back to Appointments</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
