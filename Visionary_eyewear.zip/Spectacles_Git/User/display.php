<?php
session_start();
include("connection.php");

// Include Bootstrap CSS
echo '<link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-beta3/css/bootstrap.min.css" rel="stylesheet">';

// Custom CSS for additional styling
echo '<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f8f9fa;
    }
    .receipt-container {
        max-width: 800px;
        margin: 50px auto;
        padding: 30px;
        border: 1px solid #dee2e6;
        border-radius: 10px;
        background-color: #ffffff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .receipt-header {
        border-bottom: 2px solid #dee2e6;
        padding-bottom: 10px;
        margin-bottom: 20px;
        text-align: center;
        position: relative;
    }
    .receipt-header h2 {
        margin: 0;
        font-size: 24px;
    }
    .receipt-body {
        margin-bottom: 20px;
    }
    .receipt-footer {
        border-top: 2px solid #dee2e6;
        padding-top: 10px;
        text-align: center;
    }
    .table thead {
        background-color: #343a40;
        color: #ffffff;
    }
    .table th, .table td {
        vertical-align: middle;
        border: 1px solid #dee2e6;
    }
    .total-price {
        font-size: 18px;
        font-weight: bold;
        text-align: right;
        margin-top: 20px;
    }
    .print-btn {
        margin-top: 20px;
    }
    .home-btn {
        position: absolute;
        top: 0;
        left: 0;
        margin: 10px;
    }
</style>';

// Check if the user_id is set in the session
if(isset($_SESSION['user_id'])) {
    // Display the user ID
    $user_id = $_SESSION['user_id'];
    echo '<div class="container receipt-container">';
    echo '<div class="receipt-header">';
    echo '<a href="index.php" class="btn btn-primary home-btn">Home</a>';
    echo '<h2>Receipt</h2>';
    echo '</div>';
    echo '<div class="receipt-body">';
    //echo '<p><strong>User ID:</strong> ' . $user_id . '</p>';
	
	if (isset($_SESSION['receipt_id'])) {
    $receipt_id = $_SESSION['receipt_id'];
    //echo "Receipt ID: " . $receipt_id;
} else {
    echo "Receipt ID not found in session.";
}
	
	$sql_user = "SELECT * FROM receipts WHERE id = $receipt_id";
    $result_user = $conn->query($sql_user);
	
	
	if ($result_user && $result_user->num_rows > 0) {
        // Fetch user details
        $row_user = $result_user->fetch_assoc();
        $invoice_number = $row_user['invoice_number'];
        
       // Display the invoice number
    echo '<p><strong>Invoice Number:</strong> ' . $invoice_number . '</p><br>';
        
    } else {
        echo '<p>Receipts not found.</p>';
    }

    
    
    // Prepare and execute SQL query to retrieve user details
    $sql_user = "SELECT firstname, lastname FROM users WHERE user_id = $user_id";
    $result_user = $conn->query($sql_user);

    // Check if query was successful and if user exists
    if ($result_user && $result_user->num_rows > 0) {
        // Fetch user details
        $row_user = $result_user->fetch_assoc();
        $firstname = $row_user['firstname'];
        $lastname = $row_user['lastname'];
        
        // Display firstname and lastname
        echo '<p><strong>Firstname:</strong> ' . $firstname . '</p>';
        echo '<p><strong>Lastname:</strong> ' . $lastname . '</p>';
    } else {
        echo '<p>User not found.</p>';
    }

    // Check if cart items are stored in the session
    if(isset($_SESSION['cart_items'])) {
        // Unserialize cart items
        $cart_items = unserialize($_SESSION['cart_items']);
        
        // Display cart items
        $total_price = 0; // Initialize total price
        echo '<table class="table table-striped table-bordered">';
        echo '<thead><tr><th>Product ID</th><th>Product Name</th><th>Quantity</th><th>Price</th><th>Total</th></tr></thead>';
        echo '<tbody>';
        foreach ($cart_items as $item) {
            $total_item_price = $item['product_price'] * $item['quantity'];
            // Display each item
            echo '<tr>';
            echo '<td>' . $item['product_id'] . '</td>';
            echo '<td>' . $item['product_name'] . '</td>';
            echo '<td>' . $item['quantity'] . '</td>';
            echo '<td>RM' . $item['product_price'] . '</td>';
            echo '<td>RM' . $total_item_price . '</td>';
            echo '</tr>';
            
            // Add the price of this item to the total price
            $total_price += $total_item_price;
        }
        echo '</tbody>';
        echo '</table>';
        
        // Display total price
        echo '<p class="total-price"><strong>Total Price:</strong> RM' . $total_price . '</p>';
    } else {
        echo '<p>No items in the cart.</p>';
    }

    // Fetch card number for the user
    $sql_card = "SELECT card_number FROM user_cards WHERE user_id = $user_id";
    $result_card = $conn->query($sql_card);

    if ($result_card && $result_card->num_rows > 0) {
        $row_card = $result_card->fetch_assoc();
        $card_number = $row_card['card_number'];
        
        // Display card number
        //echo '<p><strong>Card Number:</strong> ' . $card_number . '</p>';
    } else {
        echo '<p>Card not found.</p>';
    }

    // Display address from session
    if (isset($_SESSION['selected_address'])) {
        echo '<p><strong>Address:</strong> ' . $_SESSION['selected_address'] . '</p>';
    } else {
        echo '<p>Address not found.</p>';
    }

    echo '</div>'; // Close receipt-body
    echo '<div class="receipt-footer">';
    echo '<button class="btn btn-primary print-btn" onclick="printReceipt()">Print Receipt</button>';
    echo '</div>'; // Close receipt-footer
    echo '</div>'; // Close receipt-container
    
    // Close database connection
    $conn->close();
} else {
    // If user ID is not set, handle it as per your application's logic
    echo '<div class="alert alert-danger" role="alert">User ID not found.</div>';
}
?>

<script>
function printReceipt() {
    window.print();
}
</script>
