<?php
session_start();
unset($_SESSION['user_id']); // Clear the user_id session variable
session_destroy(); // Destroy the entire session
echo "Logged out successfully"; // Optional: return a success message
?>
