<?php
include("connection.php");

$receipt_id = intval($_GET['receipt_id']);

// Prepare the SQL query to get the receipt details
$sql = "
    SELECT 
        ri.product_id,
        m.name AS product_name,
        ri.quantity,
        ri.price AS item_price,
        b.name AS brand_name,
        img.image_name,
        img.image_data
    FROM 
        receipt_items ri
    INNER JOIN 
        models m ON ri.product_id = m.id
    INNER JOIN 
        brands b ON m.brand_id = b.id
    LEFT JOIN 
        images img ON m.id = img.model_id
    WHERE 
        ri.receipt_id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $receipt_id);
$stmt->execute();
$result = $stmt->get_result();

$sql_receipt = "SELECT * FROM receipts WHERE id = ?";
$stmt_receipt = $conn->prepare($sql_receipt);
$stmt_receipt->bind_param("i", $receipt_id);
$stmt_receipt->execute();
$result_receipt = $stmt_receipt->get_result();
$receipt = $result_receipt->fetch_assoc();

// Include Bootstrap CSS and Icons
echo '<link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-beta3/css/bootstrap.min.css" rel="stylesheet">';
echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">';

// Custom CSS for additional styling
echo '<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f8f9fa;
    }
    .receipt-container {
        max-width: 800px;
        margin: 50px auto;
        padding: 30px;
        border: 1px solid #dee2e6;
        border-radius: 10px;
        background-color: #ffffff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .receipt-header {
        border-bottom: 2px solid #dee2e6;
        padding-bottom: 10px;
        margin-bottom: 20px;
        text-align: center;
    }
    .receipt-header h2 {
        margin: 0;
        font-size: 24px;
    }
    .receipt-body {
        margin-bottom: 20px;
    }
    .receipt-footer {
        border-top: 2px solid #dee2e6;
        padding-top: 10px;
        text-align: center;
    }
    .table thead {
        background-color: #343a40;
        color: #ffffff;
    }
    .table th, .table td {
        vertical-align: middle;
        border: 1px solid #dee2e6;
    }
    .total-price {
        font-size: 18px;
        font-weight: bold;
        text-align: right;
        margin-top: 20px;
    }
    .print-btn {
        margin-top: 20px;
    }
    .back-btn {
        margin-bottom: 20px;
        display: inline-block;
    }
</style>';

echo '<div class="container receipt-container">';
echo '<a href="history.php" class="btn btn-secondary back-btn"><i class="bi bi-arrow-left-circle"></i> Back to History</a>';
echo '<div class="receipt-header">';
echo '<h2>Receipt Details</h2>';
echo '</div>';
echo '<div class="receipt-body">';
echo '<p><strong>Invoice Number:</strong> ' . $receipt['invoice_number'] . '</p>';
echo '<p><strong>Receipt Date:</strong> ' . $receipt['created_at'] . '</p>';

echo '</div>';

if ($result->num_rows > 0) {
    echo '<div class="receipt-body">';
    echo '<table class="table table-striped table-bordered">';
    echo '<thead><tr><th>Product Name</th><th>Brand Name</th><th>Quantity</th><th>Price</th><th>Total</th></thead>';
    echo '<tbody>';
    $total_price = 0;
    while ($row = $result->fetch_assoc()) {
        $total_item_price = $row['item_price'] * $row['quantity'];
        echo '<tr>';
        echo '<td>' . $row['product_name'] . '</td>';
        echo '<td>' . $row['brand_name'] . '</td>';
        echo '<td>' . $row['quantity'] . '</td>';
        echo '<td>RM' . number_format($row['item_price'], 2) . '</td>';
        echo '<td>RM' . number_format($total_item_price, 2) . '</td>';
        echo '</tr>';
        $total_price += $total_item_price;
    }
    echo '</tbody>';
    echo '</table>';
    echo '<p class="total-price"><strong>Total Price:</strong> RM' . number_format($receipt['total_price'], 2) . '</p>';
    echo '</div>';
} else {
    echo '<p>No items found for this receipt.</p>';
}echo '<p><strong>Delivery:</strong> ' . $receipt['delivery'] . '</p>';

echo '<div class="receipt-footer">';
echo '<button class="btn btn-primary print-btn" onclick="printReceipt()">Print Receipt</button>';
echo '</div>';
echo '</div>';

$stmt->close();
$conn->close();
?>

<script>
function printReceipt() {
    window.print();
}
</script>
