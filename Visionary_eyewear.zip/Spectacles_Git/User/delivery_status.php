<?php
// Include your database connection file
include("connection.php");

// Start the session
session_start();

// Fetch the user_id from session
$user_id = $_SESSION['user_id'];

// Initialize the selected status filter
$selected_status = isset($_GET['status_filter']) ? $_GET['status_filter'] : 'All';

// Modify the query to include the status filter
$query = "
    SELECT ds.id AS status_id, ds.status, ds.status_timestamp, ds.notes, r.invoice_number, r.total_price, r.delivery, r.created_at
    FROM delivery_status ds
    JOIN receipts r ON ds.receipt_id = r.id
    WHERE r.user_id = ?
";

if ($selected_status !== 'All') {
    $query .= " AND ds.status = ?";
}

$query .= " ORDER BY ds.status_timestamp DESC";

$stmt = mysqli_prepare($conn, $query);
if ($selected_status !== 'All') {
    mysqli_stmt_bind_param($stmt, "is", $user_id, $selected_status);
} else {
    mysqli_stmt_bind_param($stmt, "i", $user_id);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Check if there are any results
if (mysqli_num_rows($result) > 0) {
    // Fetch all the results
    $delivery_statuses = mysqli_fetch_all($result, MYSQLI_ASSOC);
} else {
    $delivery_statuses = [];
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #e9f5f5; /* Light teal background */
            color: #333; /* Standard text color */
        }
        .container {
            margin-top: 50px;
        }
        .table-container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="table-container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="text-center mb-0">Delivery Status</h2>
                <a href="index.php" class="btn btn-secondary">Back</a>
            </div>
            <form method="GET" class="mb-4">
                <div class="row">
                    <div class="col-md-4">
                        <select name="status_filter" class="form-select" onchange="this.form.submit()">
                            <option value="All" <?php echo $selected_status == 'All' ? 'selected' : ''; ?>>All</option>
                            <option value="Complete" <?php echo $selected_status == 'Complete' ? 'selected' : ''; ?>>Complete</option>
                            <option value="Delivered" <?php echo $selected_status == 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="Pending" <?php echo $selected_status == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                        </select>
                    </div>
                </div>
            </form>
            <?php if (!empty($delivery_statuses)): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Invoice Number</th>
                            <th>Total Price</th>
                            <th>Delivery</th>
                            <th>Status</th>
                            <th>Status Timestamp</th>
                            <th>Notes</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $counter = 1;
                        foreach ($delivery_statuses as $status): ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo $status['invoice_number']; ?></td>
                                <td><?php echo $status['total_price']; ?></td>
                                <td><?php echo $status['delivery']; ?></td>
                                <td><?php echo $status['status']; ?></td>
                                <td><?php echo $status['status_timestamp']; ?></td>
                                <td><?php echo $status['notes']; ?></td>
                                <td><?php echo $status['created_at']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No delivery statuses found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
