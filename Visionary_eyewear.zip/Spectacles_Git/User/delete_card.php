<?php
session_start();
include("connection.php");

if (isset($_GET['card_id'])) {
    $card_id = $_GET['card_id'];
    
    // Perform deletion query
    $query = "DELETE FROM user_cards WHERE card_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $card_id);
    mysqli_stmt_execute($stmt);

    // Check if deletion was successful
    if (mysqli_stmt_affected_rows($stmt) > 0) {
        $_SESSION['delete_card_message'] = "Card deleted successfully.";
    } else {
        $_SESSION['delete_card_message'] = "Failed to delete card.";
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    // Redirect back to the page where cards are displayed
    header("Location: user_card.php");
    exit();
} else {
    echo "Invalid request.";
}
?>
