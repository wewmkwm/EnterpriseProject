<?php
session_start();
header('Content-Type: application/json');

if (isset($_SESSION['user_id'])) {
    // Fetch username from database or session
    $username = $_SESSION['username']; // Example, adjust as needed
    echo json_encode(['loggedIn' => true, 'username' => $username]);
} else {
    echo json_encode(['loggedIn' => false]);
}
?>
