<?php
include("connection.php");

// Function to safely escape strings for SQL queries
function escape($value) {
    global $conn;
    return mysqli_real_escape_string($conn, $value);
}

// Get form data
$firstname = escape($_POST['firstname']);
$lastname = escape($_POST['lastname']);
$username = escape($_POST['username']);
$phonenumber = escape($_POST['phonenumber']);
$email = escape($_POST['email']);
$password = escape($_POST['password']);

// Check if the email or phone number already exist in the database
$check_query = "SELECT * FROM users WHERE email = '$email' OR phone_number = '$phonenumber'";
$result = $conn->query($check_query);

if ($result->num_rows > 0) {
    // If email or phone number already exist, display error message
    echo "Error: Email or phone number already exists.";
} else {
    // Check if the username already exists
    $check_username_query = "SELECT * FROM users WHERE username = '$username'";
    $username_result = $conn->query($check_username_query);

    if ($username_result->num_rows > 0) {
        // If username already exists, display error message
        echo "Error: Username already exists.";
    } else {
        // Insert data into the database
        $sql = "INSERT INTO users (user_id, firstname, lastname, username, phone_number, email, password)
        VALUES (NULL, '$firstname', '$lastname', '$username', '$phonenumber', '$email', '$password')";

        if ($conn->query($sql) === TRUE) {
            // Registration successful
            echo "New record created successfully";
            
            // Redirect to login.php after displaying success message
            echo '<script>alert("Registration successful. Please login."); window.location.replace("login.php");</script>';
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>
