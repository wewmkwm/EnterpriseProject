<?php
// Include your database connection file
include("connection.php");

// Start the session
session_start();
if (isset($_POST['selected_address'])) {
    $selected_address_id = $_POST['selected_address'];

    // Fetch the address details from the database based on $selected_address_id
    $queryAddress = "SELECT address FROM address WHERE id = ?";
    $stmt = mysqli_prepare($conn, $queryAddress);
    mysqli_stmt_bind_param($stmt, "i", $selected_address_id);
    mysqli_stmt_execute($stmt);
    $resultAddress = mysqli_stmt_get_result($stmt);
    $selected_address = mysqli_fetch_assoc($resultAddress);

    // Save the selected address into session if found
    if ($selected_address) {
        $_SESSION['selected_address'] = $selected_address['address'];
        //echo "<p>Selected Address: " . $_SESSION['selected_address'] . "</p>";
    } else {
        echo "<p>Address not found.</p>";
    }
}


if(isset($_POST['selected_card'])) {
    $_SESSION['selected_card'] = $_POST['selected_card'];

    // Decrease product quantity and clear cart items
    if(isset($_SESSION['cart_items'])) {
        $cart_items = unserialize($_SESSION['cart_items']);
        
        $user_id = $_SESSION['user_id']; // Assuming you have user_id stored in the session
        
        // Generate a unique invoice number
        $date_time = date("YmdHis");
        $random_number = rand(1000, 9999);
        $invoice_number = "INV-" . $date_time . "-" . $user_id . "-" . $random_number;
        
        // Calculate the total price
        $total_price = 0;
        foreach ($cart_items as $item) {
            $total_price += $item['product_price'] * $item['quantity'];
        }
        
        // Insert the receipt into the receipts table
        // Prepare the query to insert into receipts table
$queryInsertReceipt = "INSERT INTO receipts (user_id, invoice_number, total_price, delivery, created_at) VALUES (?, ?, ?, ?, NOW())";

// Prepare the statement
$stmt = mysqli_prepare($conn, $queryInsertReceipt);

// Bind parameters
mysqli_stmt_bind_param($stmt, "isds", $user_id, $invoice_number, $total_price, $_SESSION['selected_address']);

        mysqli_stmt_execute($stmt);
        
        // Get the inserted receipt ID
        $receipt_id = mysqli_insert_id($conn);
		
		// Save the receipt_id into session
$_SESSION['receipt_id'] = $receipt_id;
        
        // Insert initial delivery status
        $initial_status = "Pending";
        $queryInsertStatus = "INSERT INTO delivery_status (receipt_id, status) VALUES (?, ?)";
        $stmt = mysqli_prepare($conn, $queryInsertStatus);
        mysqli_stmt_bind_param($stmt, "is", $receipt_id, $initial_status);
        mysqli_stmt_execute($stmt);
        
        foreach ($cart_items as $item) {
            $product_id = $item['product_id'];
            $quantity = $item['quantity'];
            $price = $item['product_price'];
            
            // Decrease product quantity in the database
            $queryUpdateQuantity = "UPDATE models SET quantity = quantity - ? WHERE id = ?";
            $stmt = mysqli_prepare($conn, $queryUpdateQuantity);
            mysqli_stmt_bind_param($stmt, "ii", $quantity, $product_id);
            mysqli_stmt_execute($stmt);
            
            // Insert each cart item into the receipt_items table
            $queryInsertItem = "INSERT INTO receipt_items (receipt_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $queryInsertItem);
            mysqli_stmt_bind_param($stmt, "iiid", $receipt_id, $product_id, $quantity, $price);
            mysqli_stmt_execute($stmt);
        }

        // Clear cart items from the database
        $queryClearCart = "DELETE FROM cart_items WHERE user_id = ?";
        $stmt = mysqli_prepare($conn, $queryClearCart);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        
        // Redirect to the display.php page after saving the selected card and updating the database
        header("Location: display.php");
        exit(); // Stop further execution of this script after redirection
    }
}

// Fetch user's credit/debit card information
$queryCards = "SELECT card_id, card_number FROM user_cards WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $queryCards);
$user_id = $_SESSION['user_id']; // Replace with the actual user's ID from the session
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$resultCards = mysqli_stmt_get_result($stmt);

$cards = array();
while ($rowCard = mysqli_fetch_assoc($resultCards)) {
    $cards[] = $rowCard;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Card</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #e9f5f5; /* Light teal background */
            color: #333; /* Standard text color */
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
            padding: 30px;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card-selection {
            margin: 10px 0;
        }
        .card {
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 10px;
            transition: box-shadow 0.3s ease;
            position: relative;
        }
        .card:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        .card label {
            width: 100%;
            margin: 0;
            padding: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .card input {
            margin-right: 10px;
        }
        .delete-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 4px 10px;
            background-color: #dc3545;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .delete-btn:hover {
            background-color: #c82333;
        }
        .btn-primary {
            background-color: #ff6347; /* Vibrant coral color */
            border-color: #ff6347;
            color: #fff;
            padding: 12px 25px;
            border-radius: 8px;
            width: 100%;
            margin-top: 20px;
            transition: all 0.2s ease-in-out;
        }
        .btn-primary:hover {
            background-color: #e5533d; /* Darker coral on hover */
            border-color: #e5533d;
            transform: translateY(-2px); /* Slight lift on hover */
        }
        .btn-secondary {
            background-color: #007bff; /* Blue color */
            border-color: #007bff;
            color: #fff;
            padding: 12px 25px;
            border-radius: 8px;
            width: 100%;
            margin-top: 10px;
            transition: all 0.2s ease-in-out;
        }
        .btn-secondary:hover {
            background-color: #0056b3; /* Darker blue on hover */
            border-color: #0056b3;
            transform: translateY(-2px); /* Slight lift on hover */
        }
		.delete-btn {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 4px 10px;
    background-color: #dc3545;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    margin-top: 40px;
}
    </style>
</head>
<body>
    <div class="container">
        <a href="address.php" class="btn btn-outline-primary mb-3">Back to Addresses</a>
        <h2 class="text-center mb-4">Select Card</h2>
        <form action="#" method="post">
            <div id="cards-container">
                <?php foreach ($cards as $card): ?>
                    <div class="card card-selection">
                        <label>
                            <input type="radio" name="selected_card" value="<?php echo $card['card_id']; ?>">
                            <span>**** **** **** <?php echo substr($card['card_number'], -4); ?></span>
                        </label>
                        <button type="button" class="delete-btn" onclick="deleteCard(<?php echo $card['card_id']; ?>)">Delete</button>
                    </div>
                <?php endforeach; ?>
            </div>
            <button type="submit" class="btn btn-primary">Proceed</button>
        </form>
        <a href="add_card.php" class="btn btn-secondary mt-2">Add Card</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>

    <script>
        function deleteCard(cardId) {
            if (confirm("Are you sure you want to delete this card?")) {
                // You can use AJAX to send a request to delete the card
                // For simplicity, assuming AJAX request is handled separately
                // Redirect to delete_card.php with cardId as parameter
                window.location.href = 'delete_card.php?card_id=' + cardId;
            }
        }
    </script>
</body>
</html>



