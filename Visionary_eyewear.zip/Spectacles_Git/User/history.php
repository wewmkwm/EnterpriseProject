<?php
session_start();
include("connection.php");
include("NavBar.php");
// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "You need to log in to view your purchase history.";
    exit;
}

$user_id = $_SESSION['user_id'];

// Prepare the SQL query to get the user's receipts
$sql = "
    SELECT 
        r.id AS receipt_id,
        r.invoice_number,
        r.total_price,
        r.created_at AS receipt_date
    FROM 
        receipts r
    WHERE 
        r.user_id = ?
    ORDER BY 
        r.created_at DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Purchase History</title>
<!-- Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-beta3/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h1>Your Purchase History</h1>

    <?php
    if ($result->num_rows > 0) {
        echo "<table class='table table-striped'>";
        echo "<thead><tr><th>Receipt ID</th><th>Invoice Number</th><th>Receipt Date</th><th>Total Price</th><th>Action</th></tr></thead>";
        echo "<tbody>";
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["receipt_id"] . "</td>
                    <td>" . $row["invoice_number"] . "</td>
                    <td>" . $row["receipt_date"] . "</td>
                    <td>RM" . number_format($row["total_price"], 2) . "</td>
                    <td><a href='view_receipt.php?receipt_id=" . $row["receipt_id"] . "' class='btn btn-primary'>View Receipt</a></td>
                  </tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<div class='alert alert-info' role='alert'>You have no purchase history.</div>";
    }

    $stmt->close();
    $conn->close();
    ?>
</div>

</body>
</html>
