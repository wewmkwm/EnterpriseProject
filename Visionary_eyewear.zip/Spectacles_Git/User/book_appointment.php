<?php
include("connection.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $appointment_datetime = $appointment_date . ' ' . $appointment_time;

    // Check if the selected appointment date and time is already booked
    $query = "SELECT COUNT(*) AS count FROM appointments WHERE appointment_date = ? AND time = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ss", $appointment_date, $appointment_time);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    if ($row['count'] > 0) {
        // Appointment slot already booked
        $_SESSION['error_message'] = "The selected date and time is already booked by others. Please choose another date or time.";
        header("Location: calender_appointment.php");
        exit();
    } else {
        // Start a transaction
        mysqli_begin_transaction($conn);

        try {
            // Insert appointment data into the appointments table
            $query = "INSERT INTO appointments (user_id, appointment_date, time, created_at) VALUES (?, ?, ?, NOW())";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "iss", $user_id, $appointment_date, $appointment_time);
            mysqli_stmt_execute($stmt);
            $appointment_id = mysqli_insert_id($conn);

            // Fetch cart items from the cart_items table
            $query = "SELECT product_id, quantity FROM cart_items WHERE user_id = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $cart_items = mysqli_fetch_all($result, MYSQLI_ASSOC);

            // Insert each cart item into the appointment_products table
            foreach ($cart_items as $item) {
                $frame_id = $item['product_id'];
                $frame_quantity = $item['quantity'];

                $query = "INSERT INTO appointment_products (frame_id, appointment_id, frame_quantity) VALUES (?, ?, ?)";
                $stmt = mysqli_prepare($conn, $query);
                mysqli_stmt_bind_param($stmt, "iii", $frame_id, $appointment_id, $frame_quantity);
                mysqli_stmt_execute($stmt);
            }

            // Clear the cart items after appointment is made
            $query = "DELETE FROM cart_items WHERE user_id = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);

            // Commit the transaction
            mysqli_commit($conn);

            // Redirect to a success page or show a success message
            header("Location: view_cart.php");
            exit();

        } catch (Exception $e) {
            // Rollback the transaction in case of error
            mysqli_rollback($conn);
            
            // Set error message in session and redirect back to the form
            $_SESSION['error_message'] = "There was an error booking your appointment. Please try again.";
            header("Location: calender_appointment.php");
            exit();
        }
    }
}
?>
