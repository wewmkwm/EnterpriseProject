<?php
include("connection.php");

// Initialize variables
$search = ""; // Default empty search
$conditions = []; // Array to store search conditions

// Check if search term is provided
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    // Split search into keywords for flexible matching
    $keywords = explode(" ", $search);
    
    // Prepare conditions for each keyword
    foreach ($keywords as $keyword) {
        $conditions[] = "firstname LIKE '%$keyword%' OR 
                         lastname LIKE '%$keyword%' OR 
                         username LIKE '%$keyword%' OR 
                         phone_number LIKE '%$keyword%' OR 
                         email LIKE '%$keyword%'";
    }
}

// Build SQL query
if (!empty($conditions)) {
    $query = "SELECT * FROM users WHERE " . implode(" OR ", $conditions);
} else {
    $query = "SELECT * FROM users";
}

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users - Admin Panel</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center mb-5">View Users</h1>
                <!-- Search Bar -->
                <form action="view_search_customer.php" method="GET" class="mb-3">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search by First Name, Last Name, Username, Phone, Email" name="search" value="<?php echo htmlspecialchars($search); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="submit">Search</button>
                        </div>
                    </div>
                </form>
<!-- Back Button -->
                <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No.</th> <!-- Changed User ID to No. -->
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Username</th>
                            <th>Phone Number</th>
                            <th>Email</th>
                            <th>Password</th> <!-- Displaying Password with asterisks -->
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1; ?>
                        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><?php echo $row['firstname']; ?></td>
                                <td><?php echo $row['lastname']; ?></td>
                                <td><?php echo $row['username']; ?></td>
                                <td><?php echo $row['phone_number']; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td><?php echo str_repeat('*', strlen($row['password'])); ?></td> <!-- Displaying Password with asterisks -->
                                <td>
                                    <a href="view_purchase_history.php?user_id=<?php echo $row['user_id']; ?>" class="btn btn-sm btn-info ml-2">View Purchase History</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
