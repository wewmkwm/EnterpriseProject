<?php
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs
    $appointment_id = $_POST['appointment_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];

    // Update the appointment in the database
    $query = "UPDATE appointments SET appointment_date = ?, time = ? WHERE appointment_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssi", $appointment_date, $appointment_time, $appointment_id);

    if (mysqli_stmt_execute($stmt)) {
        // Appointment updated successfully
        header("Location: view_appointment.php"); // Redirect to manage appointments page
        exit();
    } else {
        // Handle update failure
        echo "Error updating appointment: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>
