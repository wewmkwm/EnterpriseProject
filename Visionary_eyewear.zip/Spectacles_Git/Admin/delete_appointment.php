<?php
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['appointment_id'])) {
    // Sanitize input to prevent SQL injection
    $appointment_id = mysqli_real_escape_string($conn, $_POST['appointment_id']);

    // Delete related records in appointment_products table first
    $delete_related_query = "DELETE FROM appointment_products WHERE appointment_id = ?";
    $stmt_related = mysqli_prepare($conn, $delete_related_query);
    mysqli_stmt_bind_param($stmt_related, "i", $appointment_id);

    if (mysqli_stmt_execute($stmt_related)) {
        // Now delete appointment from the appointments table
        $delete_appointment_query = "DELETE FROM appointments WHERE appointment_id = ?";
        $stmt_appointment = mysqli_prepare($conn, $delete_appointment_query);
        mysqli_stmt_bind_param($stmt_appointment, "i", $appointment_id);

        if (mysqli_stmt_execute($stmt_appointment)) {
            // Appointment and related records deleted successfully
            mysqli_stmt_close($stmt_related);
            mysqli_stmt_close($stmt_appointment);
            mysqli_close($conn);
            header("Location: view_appointment.php"); // Redirect to manage appointments page
            exit();
        } else {
            // Handle appointment deletion failure
            echo "Error deleting appointment: " . mysqli_error($conn);
        }
    } else {
        // Handle related records deletion failure
        echo "Error deleting related records: " . mysqli_error($conn);
    }
} else {
    // Redirect to error page or manage appointments page if appointment_id is not provided
    header("Location: view_appointment.php");
    exit();
}
?>
