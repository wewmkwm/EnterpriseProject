
<?php
include("connection.php");

// Check if appointment_id is set in the request
if (isset($_GET['appointment_id'])) {
    $appointment_id = $_GET['appointment_id'];

    // Fetch appointment details from the database
    $query = "SELECT * FROM appointments WHERE appointment_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $appointment_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        // Assign fetched data to $appointment variable
        $appointment = $row;
    } else {
        // Handle case where appointment with given ID does not exist
        die("Appointment not found");
    }
} else {
    // Handle case where appointment_id is not provided
    die("Appointment ID not specified");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Appointment</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h2>Edit Appointment</h2>
                    </div>
                    <div class="card-body">
                        <form action="update_appointment.php" method="POST">
                            <input type="hidden" name="appointment_id" value="<?php echo $appointment_id; ?>">
                            <div class="form-group">
                                <label for="appointment-date">Select a date:</label>
                                <input type="date" class="form-control" id="appointment-date" name="appointment_date" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" value="<?php echo $appointment['appointment_date']; ?>">
                            </div>
                            <div class="form-group">
                                <label for="appointment-time">Select a time:</label>
                                <select class="form-control" id="appointment-time" name="appointment_time">
                                    <option value="11:00" <?php if ($appointment['time'] == '11:00') echo 'selected'; ?>>11:00 AM</option>
                                    <option value="14:00" <?php if ($appointment['time'] == '14:00') echo 'selected'; ?>>2:00 PM</option>
                                    <option value="17:00" <?php if ($appointment['time'] == '17:00') echo 'selected'; ?>>5:00 PM</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Update Appointment</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set the min attribute for the date input to tomorrow's date
            const today = new Date();
            const tomorrow = new Date(today);
            tomorrow.setDate(today.getDate() + 1);
            const tomorrowDate = tomorrow.toISOString().split('T')[0];
            document.getElementById('appointment-date').setAttribute('min', tomorrowDate);

            // Disable past dates in the date input
            const dateInput = document.getElementById('appointment-date');
            dateInput.addEventListener('input', function() {
                const selectedDate = new Date(dateInput.value);
                if (selectedDate < tomorrow) {
                    dateInput.value = tomorrowDate;
                }
            });
        });
    </script>
</body>
</html>
