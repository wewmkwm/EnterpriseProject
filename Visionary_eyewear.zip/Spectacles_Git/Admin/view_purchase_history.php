<?php
include("connection.php");

// Ensure user_id is passed via GET parameter
if (!isset($_GET['user_id'])) {
    die("User ID not provided.");
}

$user_id = $_GET['user_id'];

// Fetch user information from users table
$query_user = "SELECT * FROM users WHERE user_id = ?";
$stmt_user = mysqli_prepare($conn, $query_user);
mysqli_stmt_bind_param($stmt_user, "i", $user_id);
mysqli_stmt_execute($stmt_user);
$user_result = mysqli_stmt_get_result($stmt_user);
$user = mysqli_fetch_assoc($user_result);

if (!$user) {
    die("User not found.");
}

// Fetch receipts for the user
$query_receipts = "SELECT * FROM receipts WHERE user_id = ?";
$stmt_receipts = mysqli_prepare($conn, $query_receipts);
mysqli_stmt_bind_param($stmt_receipts, "i", $user_id);
mysqli_stmt_execute($stmt_receipts);
$receipts_result = mysqli_stmt_get_result($stmt_receipts);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase History - <?php echo $user['username']; ?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center mb-5">Purchase History - <?php echo $user['username']; ?></h1>
                <div class="card mb-4">
                    <div class="card-header">
                        User Information
                    </div>
                    <div class="card-body">
                        <p><strong>User ID:</strong> <?php echo $user['user_id']; ?></p>
                        <p><strong>Name:</strong> <?php echo $user['firstname'] . ' ' . $user['lastname']; ?></p>
                        <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
                        <p><strong>Phone Number:</strong> <?php echo $user['phone_number']; ?></p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        Purchase History
                    </div>
                    <div class="card-body">
                        <?php if (mysqli_num_rows($receipts_result) > 0) : ?>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Invoice Number</th>
                                            <th>Total Price</th>
                                            <th>Delivery</th>
                                            <th>Created At</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($receipt = mysqli_fetch_assoc($receipts_result)) : ?>
                                            <tr>
                                                <td><?php echo $receipt['invoice_number']; ?></td>
                                                <td><?php echo $receipt['total_price']; ?></td>
                                                <td><?php echo $receipt['delivery']; ?></td>
                                                <td><?php echo $receipt['created_at']; ?></td>
                                                <td>
                                                    <a href="view_receipt.php?receipt_id=<?php echo $receipt['id']; ?>" class="btn btn-info btn-sm">View Details</a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else : ?>
                            <p>No purchase history found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
