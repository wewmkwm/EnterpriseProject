<?php
include("connection.php");

// Default filter condition
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'upcoming';

// Define the base query with order by clause
$query = "SELECT * FROM appointments";

// Adjust query based on filter
switch ($filter) {
    case 'past':
        $query .= " WHERE appointment_date < CURDATE()";
        break;
    case 'upcoming':
        $query .= " WHERE appointment_date >= CURDATE()";
        break;
    default:
        // All appointments (no additional condition)
        break;
}

$query .= " ORDER BY appointment_date DESC, time DESC";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Appointments - Admin Panel</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row mb-3">
            <div class="col-md-12">
                
                <!-- Filter options -->
                <select class="form-control mt-3" onchange="filterAppointments(this.value)">
                    <option value="upcoming" <?php if ($filter === 'upcoming') echo 'selected'; ?>>Upcoming Appointments</option>
                    <option value="past" <?php if ($filter === 'past') echo 'selected'; ?>>Past Appointments</option>
                    <option value="all" <?php if ($filter === 'all') echo 'selected'; ?>>All Appointments</option>
                </select>
            </div>
        </div>
		
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center mb-5">View Appointments</h1>
				<a href="index.php" class="btn btn-secondary">Back</a>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Appointment ID</th>
                            <th>User ID</th>
                            <th>Appointment Date</th>
                            <th>Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                            <tr>
                                <td><?php echo $row['appointment_id']; ?></td>
                                <td><?php echo $row['user_id']; ?></td>
                                <td><?php echo $row['appointment_date']; ?></td>
                                <td><?php echo $row['time']; ?></td>
                                <td>
                                    <a href="appointment_details.php?appointment_id=<?php echo $row['appointment_id']; ?>" class="btn btn-info btn-sm">View Details</a>
                                    <a href="edit_appointment.php?appointment_id=<?php echo $row['appointment_id']; ?>" class="btn btn-primary btn-sm">Edit</a>
                                    <!-- Use a form to perform delete operation -->
                                    <form action="delete_appointment.php" method="post" style="display: inline;">
                                        <input type="hidden" name="appointment_id" value="<?php echo $row['appointment_id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this appointment?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // JavaScript function to handle filter change
        function filterAppointments(filter) {
            window.location.href = 'view_appointment.php?filter=' + filter;
        }
    </script>
</body>
</html>
