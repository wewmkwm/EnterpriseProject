<?php
include("connection.php");

// Check if receipt_id is provided in the query string
if (isset($_GET['receipt_id'])) {
    $receipt_id = $_GET['receipt_id'];

    // Fetch receipt details
    $query = "SELECT r.*, u.firstname, u.lastname 
              FROM receipts r 
              INNER JOIN users u ON r.user_id = u.user_id 
              WHERE r.id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $receipt_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        // Fetch receipt items
        $query_items = "SELECT ri.*, m.name AS product_name 
                        FROM receipt_items ri 
                        INNER JOIN models m ON ri.product_id = m.id 
                        WHERE ri.receipt_id = ?";
        $stmt_items = mysqli_prepare($conn, $query_items);
        mysqli_stmt_bind_param($stmt_items, "i", $receipt_id);
        mysqli_stmt_execute($stmt_items);
        $result_items = mysqli_stmt_get_result($stmt_items);
    } else {
        die("Receipt not found.");
    }
} else {
    die("Receipt ID not provided.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Receipt</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center mb-5">Receipt Details</h1>
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title">Receipt #<?php echo $row['id']; ?></h3>
                        <p class="card-text">Total Price: <?php echo $row['total_price']; ?></p>
                        <p class="card-text">Delivery: <?php echo $row['delivery']; ?></p>
                        <p class="card-text">Created At: <?php echo $row['created_at']; ?></p>
                        <p class="card-text">Customer: <?php echo $row['firstname'] . ' ' . $row['lastname']; ?></p>
                    </div>
                </div>

                <h2 class="mt-5">Items Purchased</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Price per Unit</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($item = mysqli_fetch_assoc($result_items)) : ?>
                            <tr>
                                <td><?php echo $item['product_name']; ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><?php echo $item['price']; ?></td>
                                <td><?php echo $item['quantity'] * $item['price']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-12">
                <a href="view_customer.php" class="btn btn-primary">Back to Receipts</a>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
