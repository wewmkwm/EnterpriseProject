<?php
include("connection.php");

if (isset($_GET['appointment_id'])) {
    $appointment_id = $_GET['appointment_id'];

    // Fetch appointment details
    $query = "SELECT * FROM appointments WHERE appointment_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $appointment_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $appointment = mysqli_fetch_assoc($result);

    // Fetch products associated with the appointment, including product details from models table
    $query = "SELECT ap.*, m.name AS model_name FROM appointment_products ap
              INNER JOIN models m ON ap.frame_id = m.id
              WHERE ap.appointment_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $appointment_id);
    mysqli_stmt_execute($stmt);
    $products_result = mysqli_stmt_get_result($stmt);
    $products = mysqli_fetch_all($products_result, MYSQLI_ASSOC);
}

if (!$appointment) {
    die("Appointment not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Appointment Details - Admin Panel</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center mb-5">Appointment Details</h1>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Appointment ID: <?php echo $appointment['appointment_id']; ?></h5>
                        <p class="card-text">User ID: <?php echo $appointment['user_id']; ?></p>
                        <p class="card-text">Appointment Date: <?php echo $appointment['appointment_date']; ?></p>
                        <p class="card-text">Time: <?php echo $appointment['time']; ?></p>
                        <h5 class="card-title mt-4">Products Selected</h5>
                        <ul class="list-group">
                            <?php foreach ($products as $product) : ?>
                                <li class="list-group-item"><?php echo $product['model_name']; ?> - Quantity: <?php echo $product['frame_quantity']; ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <a href="view_appointment.php" class="btn btn-primary mt-4">Back to Appointments</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
